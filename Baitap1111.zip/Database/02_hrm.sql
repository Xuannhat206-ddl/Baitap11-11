CREATE TABLE phongban(mapb int GENERATED ALWAYS AS IDENTITY PRIMARY KEY,tenpb varchar(100) NOT NULL,mota varchar(255));
CREATE TABLE nhanvien(manv int GENERATED ALWAYS AS IDENTITY PRIMARY KEY,hoten varchar(100) NOT NULL,ngaysinh date,cccd varchar(20) UNIQUE,mapb int REFERENCES phongban,luongcoban numeric(18,2) CHECK(luongcoban>0),hesoluong double precision DEFAULT 1.0);
CREATE TABLE bangchamcong(macong int GENERATED ALWAYS AS IDENTITY PRIMARY KEY,manv int REFERENCES nhanvien,thangnam varchar(7),songaycong double precision CHECK(songaycong BETWEEN 0 AND 31),sogioot double precision DEFAULT 0,UNIQUE(manv,thangnam));
CREATE TABLE bangluong(maluong int GENERATED ALWAYS AS IDENTITY PRIMARY KEY,manv int REFERENCES nhanvien,thangnam varchar(7),thuclinh numeric(18,2),UNIQUE(manv,thangnam));
INSERT INTO phongban(tenpb) VALUES('Kế toán'),('Kỹ thuật');
INSERT INTO nhanvien(hoten,cccd,mapb,luongcoban,hesoluong) VALUES('Nguyễn Văn An','001000000001',1,8000000,1.2),('Trần Thị Bình','001000000002',2,9000000,1.3);
