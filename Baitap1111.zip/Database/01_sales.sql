CREATE TABLE nhanvien(manv int GENERATED ALWAYS AS IDENTITY PRIMARY KEY,tennv varchar(100) NOT NULL,sodienthoai varchar(15) UNIQUE,chucvu varchar(50));
CREATE TABLE khachhang(makh int GENERATED ALWAYS AS IDENTITY PRIMARY KEY,tenkh varchar(100) NOT NULL,dienthoai varchar(15) UNIQUE,diemtichluy int NOT NULL DEFAULT 0);
CREATE TABLE sanpham(masp varchar(20) PRIMARY KEY,tensp varchar(150) NOT NULL,giaban numeric(18,2) NOT NULL CHECK(giaban>0),soluongton int NOT NULL CHECK(soluongton>=0));
CREATE TABLE hoadon(mahd int GENERATED ALWAYS AS IDENTITY PRIMARY KEY,ngaylap timestamp DEFAULT CURRENT_TIMESTAMP,manv int NOT NULL REFERENCES nhanvien,makh int REFERENCES khachhang,tongtien numeric(18,2) NOT NULL);
CREATE TABLE chitiethoadon(mahd int REFERENCES hoadon ON DELETE CASCADE,masp varchar(20) REFERENCES sanpham,soluong int CHECK(soluong>0),dongia numeric(18,2),PRIMARY KEY(mahd,masp));
INSERT INTO nhanvien(tennv,chucvu) VALUES('Nguyễn Văn An','Thu ngân');
INSERT INTO khachhang(tenkh) VALUES('Khách mẫu');
INSERT INTO sanpham VALUES('SP01','Sữa tươi',32000,100),('SP02','Mì gói',5000,200),('SP03','Nước suối',8000,150);
